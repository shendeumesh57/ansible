#!/bin/bash

PS_OUT=$(ps -F -T -C httpd)
#RP=$( echo "$PS_OUT" | grep root | grep -wv grep | awk {'print $14'} | awk -F / {'print $6'})


#for rp in $RP
#do
  echo -e -n "SINGLE_INST" "\t" `echo "$PS_OUT" |  wc -l ` "\t" "1024\n"