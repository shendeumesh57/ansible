#!/bin/bash -e

if [ "$1" = "" ]; then
        echo "missing arg1: filename"
        exit -1
fi
certfilename="$1"

if [ "$2" = "" ]; then
        echo "missing arg2: url"
        exit -1
fi
certurl="$2"

##############################################

address()
{
    echo "$1" | sed 's|.*//||;s|/.*$||'
}

##############################################

check_cert_url()
{
    # only https can be used to get a certificate
    case "$2" in
        https://*) ;;
        *) return 1 ;;
    esac

    addr=`address "$2"`
    expdate=`timeout 1 openssl s_client -connect "$addr" </dev/null 2>/dev/null |\
    openssl x509 -noout -dates 2>/dev/null |\
    awk -F= 'tolower($1)~/notafter/ {print $2};'`

    if [[ "$expdate" = "" ]]; then
        return 1
    fi

    timestamp1=`date +%s -d "$expdate"`
    timestamp2=`date +%s`
    echo `basename "$1"` / `address "$2"` / "$expdate" / $(( (timestamp1 - timestamp2) / 86400 )) / connect
    return 0
}

##############################################

check_cert_file()
{
    if [ ! -r "$1" ]; then
        return 1
    fi

    tmpfile="/tmp/flexcheck_cert_errors.$$"
    set +e
    date1=`openssl x509 -noout -in "$1" -enddate 2>$tmpfile  | awk -F= 'tolower($1)~/notafter/ {print $2};'`
    set -e
    if [ "$date1" = "" ]; then
        errmsg=`head -1 $tmpfile | sed 's:/:\\\\:g'`
        rm -f $tmpfile
        [ "$errmsg" = "" ] && errmsg="could not retrieve enddate"
        echo `basename "$1"` / `address "$2"` / "$errmsg" / 0 / error
        return 0
    else
        rm -f $tmpfile
    fi

    timestamp1=`date +%s -d "$date1"`
    timestamp2=`date +%s`
    echo `basename "$1"` / `address "$2"` / "$date1" / $(( (timestamp1 - timestamp2) / 86400 )) / file
    return 0
}

##############################################

check_failure()
{
    echo `basename $1` / `address "$2"` / no such certificate / 0 / error
}

##############################################

check_cert_url  "$certfilename" "$certurl" || \
check_cert_file "$certfilename" "$certurl" || \
check_failure   "$certfilename" "$certurl"

exit 0
