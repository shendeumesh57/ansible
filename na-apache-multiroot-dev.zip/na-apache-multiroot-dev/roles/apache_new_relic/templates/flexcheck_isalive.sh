#!/bin/bash

url=$1; shift;
timeout=$1; shift;
[[ "$timeout" = "" ]] && timeout=1
if [[ "$url" != "" ]]; then
    ( curl -m "$timeout" -sk -o /dev/null -w "$url|%{http_code}|%{time_total}|" "$url"; echo $? ) |\
    awk -F\| '{printf("%s|%.1f\n",$0, ($2==200 || $2==301 || $2==302 || $2==404)  && $4==0 ? 1:0);}'
