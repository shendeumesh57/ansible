Beckend
=========

role will loop over dictionary and create jk.vhost config file with balancers 

Requirements
------------

role reqiories dictionary with all variables <br>

```"survey_BACKEND": "{\"survey_BACKEND\": {\"context1\": {\"server0\": {\"url\": \"https:\/\/localhost:8080\",\"jvm_route\": \"8080\"},\"server1\": {\"url\": \"https:\/\/localhost:8081\",\"jvm_route\": \"8081\"},\"server2\": {\"url\": \"https:\/\/localhost:8082\",\"jvm_route\": \"8082\"},\"server3\": {\"url\": \"https:\/\/localhost:8083\",\"jvm_route\": \"8083\"},\"name\": \"\/test\"},\"context2\": {\"server0\": {\"url\": \"https:\/\/localhost:8080\",\"jvm_route\": \"8080\"},\"server1\": {\"url\": \"https:\/\/localhost:8081\",\"jvm_route\": \"8081\"},\"server2\": {\"url\": \"https:\/\/localhost:8082\",\"jvm_route\": \"8082\"},\"server3\": {\"url\": \"https:\/\/localhost:8083\",\"jvm_route\": \"8083\"},\"name\": \"\/prod\"}  }}" ,
```

```
survey_BACKEND: 
          context1: 
            server0:
              url: https://localhost:8080
              jvm_route: "8080"
            server1:
              url: https://localhost:8081
              jvm_route: "8081"
            server2:
              url: https://localhost:8082
              jvm_route: "8082"
            server3:
              url: https://localhost:8083
              jvm_route: "8083"
            name: "/test"
          context2: 
            server0:
              url: https://localhost:8080
              jvm_route: "8080"
            server1:
              url: https://localhost:8081
              jvm_route: "8081"
            server2:
              url: https://localhost:8082
              jvm_route: "8082"
            server3:
              url: https://localhost:8083
              jvm_route: "8083"
            name: "/prod"
```



# full query

```POST https://ansibleportal.web.allianz/api/v2/workflow_job_templates/651/launch/ HTTP/1.1
content-type: application/json
Authorization: Bearer aaaaaa

{
    "limit": "slb20902.srv.allianz",
    "extra_vars": {
            "survey_STAGE": "PROD",
            "survey_INSTANCE_URL": "www.apache-test1.allianz",
            "survey_ALIAS": "www.apache-test1.awin",
            "survey_HTTP_PORT_LB": "80",
            "survey_HTTPS_PORT_LB": "443",
            "survey_FARM_SERVERS": "slb20902",
            "survey_CERT_REQ": "No",
            "survey_SPONSOR": "EXTERN.KOVALOK_VOLODYMYR@ALLIANZ.DE",
            "survey_BACKEND": "{\"survey_BACKEND\": {\"context1\": {\"server0\": {\"url\": \"https:\/\/localhost:8080\",\"jvm_route\": \"8080\"},\"server1\": {\"url\": \"https:\/\/localhost:8081\",\"jvm_route\": \"8081\"},\"server2\": {\"url\": \"https:\/\/localhost:8082\",\"jvm_route\": \"8082\"},\"server3\": {\"url\": \"https:\/\/localhost:8083\",\"jvm_route\": \"8083\"},\"name\": \"\/test\"},\"context2\": {\"server0\": {\"url\": \"https:\/\/localhost:8080\",\"jvm_route\": \"8080\"},\"server1\": {\"url\": \"https:\/\/localhost:8081\",\"jvm_route\": \"8081\"},\"server2\": {\"url\": \"https:\/\/localhost:8082\",\"jvm_route\": \"8082\"},\"server3\": {\"url\": \"https:\/\/localhost:8083\",\"jvm_route\": \"8083\"},\"name\": \"\/prod\"}  }}" ,
            "survey_SIZE": "SMALL"
    }
}
```



Role Variables
--------------

A description of the settable variables for this role should go here, including any variables that are in defaults/main.yml, vars/main.yml, and any variables that can/should be set via parameters to the role. Any variables that are read from other roles and/or the global scope (ie. hostvars, group vars, etc.) should be mentioned here as well.

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: username.rolename, x: 42 }

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
