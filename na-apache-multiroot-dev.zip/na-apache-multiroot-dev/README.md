# apache-rproxy-playbook
apache installation repo for allianz
<br>
below is example of single RP configuration <br>
loading order is: rp_prod_alz.conf -> apache.prof -> global.cfg -> rp_prod_alz/*.conf
```
.
├── etc
│   └── httpd
│       ├── conf
│       │   ├── global.cfg
│       │   └── rp_prod_alz.conf
│       ├── conf.d
│       │   └── cert
│       │       ├── ca-bundle.dev
│       │       ├── ca-bundle.prod
│       │       └── ca-bundle.si
│       │       └── alz.allianz.com.pph
│       │       └── alz.allianz.com.crt
│       │       └── alz.allianz.com.key
│       ├── conf.modules.d
│       │   ├── 00-base.conf
│       │   ├── 00-dav.conf
│       │   ├── 00-lua.conf
│       │   ├── 00-mpm.conf
│       │   ├── 00-proxy.conf
│       │   ├── 00-ssl.conf
│       │   ├── 00-systemd.conf
│       │   └── 01-cgi.conf
│       └── rp_prod_alz
│           ├── alz.allianz.com-443-sec.conf
│           ├── alz.allianz.com-80.conf
│           ├── apache.prof
│           ├── jk.root
│           └── jk.vhost
└── var
    ├── log
    │   └── httpd
    │       ├── alz.allianz.com-443-sec
    │       ├── alz.allianz.com-80
    │       └── default
    │           └── rp_prod_alz
    └── www
        └── html
            ├── alz.allianz.com
            │   ├── cgi-bin
            │   └── docs
            └── isalive
                └── isalive.html
```


# Molecule testing 
tag added to ignore git 

```molecule converge -- --skip-tags="noGit"```
<br>

``` -prod tag for prod tasks only, such as request ip or certificate```